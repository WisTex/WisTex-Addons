Extra Theme Navigation Bar Variables
================================

Allows admins to set navigation bar variables defined by a theme. Used in Neuhub themes and potentially some other themes.
